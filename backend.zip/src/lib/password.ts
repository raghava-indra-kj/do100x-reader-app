import argon2 from "argon2";

export async function hashPassword(plain: string): Promise<string> {
    return argon2.hash(plain);
}

export async function verifyPassword({ hash, plain }: { hash: string; plain: string }): Promise<boolean> {
    return argon2.verify(hash, plain);
}
