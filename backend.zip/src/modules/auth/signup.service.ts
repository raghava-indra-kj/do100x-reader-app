import { prisma } from "@core/db/prisma";
import { hashPassword } from "@lib/password";
import { generateUuid } from "@lib/uuid";
import { createUserHomepage } from "@modules/page/create-user-homepage.service";
import { UserError } from "@modules/user/errors/user-error";
import { USER_EMAIL_TAKEN } from "@modules/user/errors/user-error.constants";
import { toAuthUser } from "./auth-result.mapper";
import { AuthResult, AuthToken } from "./auth.models";
import { createSession } from "./session.service";
import { SignupInput, SignupInputSchema } from "./signup.models";

export async function signupUser(input: SignupInput): Promise<AuthResult> {
    const parsed = SignupInputSchema.parse(input);

    const existing = await prisma.appuser.findUnique({ where: { email: parsed.email } });
    if (existing) {
        throw new UserError({ errorCode: USER_EMAIL_TAKEN, message: "Email is already taken" });
    }

    const hashedPassword = await hashPassword(parsed.password);
    const userId = generateUuid();

    const { updatedUser, accessToken } = await prisma.$transaction(async (tx) => {
        await tx.appuser.create({
            data: {
                id: userId,
                name: parsed.name,
                email: parsed.email,
                password: hashedPassword,
                createdAt: new Date(),
            },
        });

        const updatedUser = await createUserHomepage({ tx, userId });
        const accessToken = await createSession({ tx, userId });

        return { updatedUser, accessToken };
    });

    const user = toAuthUser(updatedUser);
    const token: AuthToken = { accessToken };

    return { user, token };
}
